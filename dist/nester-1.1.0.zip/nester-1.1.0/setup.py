from distutils.core  import setup

setup(
        name           = 'nester',
        version        = '1.1.0',
        py_modules     = ['nester'],
        author         = 'mao',
        author_email   = '540329033@qq.com',
        description    = 'A simple printer of nested lists',
    )
